$(document).ready(function() {
    var graph = new joint.dia.Graph;
    var xCoord = 10;
    var paper = new joint.dia.Paper({
        el: document.getElementById('myholder'),
        model: graph,
        width: 600,
        height: 600,
        gridSize: 1
    });

    function createNode(cordX, yCoord) {
        xCoord = cordX + 10;
        var rect = new joint.shapes.standard.Rectangle();
        rect.position(cordX, yCoord);
        rect.resize(100, 40);
        rect.attr({
            body: {
                fill: 'blue'
            },
            label: {
                text: 'Hello',
                fill: 'white'
            }
        });
        rect.addTo(graph);
    }

    $("#nodeCreator").click(function(){
        createNode(xCoord, 100);
    })

    

    var link = new joint.shapes.standard.Link();
    link.source(rect);
    link.target(rect2);
    link.addTo(graph);



    
})